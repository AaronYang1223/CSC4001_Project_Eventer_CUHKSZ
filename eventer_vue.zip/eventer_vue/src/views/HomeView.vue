<template>
  <div class="home">
    <h1>Homepage</h1>
  </div>
</template>

<script>


export default {
  name: 'HomeView',

}
</script>
